package it.vfsfitvnm.vimusic.enums

enum class SongSortBy {
    PlayTime,
    Title,
    DateAdded
}
