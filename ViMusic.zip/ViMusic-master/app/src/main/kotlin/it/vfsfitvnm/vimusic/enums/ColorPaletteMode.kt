package it.vfsfitvnm.vimusic.enums

enum class ColorPaletteMode {
    Light,
    Dark,
    System
}
