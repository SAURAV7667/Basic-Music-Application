package it.vfsfitvnm.vimusic.enums

enum class PlaylistSortBy {
    Name,
    DateAdded,
    SongCount
}
