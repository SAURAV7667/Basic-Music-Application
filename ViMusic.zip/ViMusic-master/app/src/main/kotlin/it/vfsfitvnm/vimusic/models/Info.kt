package it.vfsfitvnm.vimusic.models

data class Info(
    val id: String,
    val name: String?
)
