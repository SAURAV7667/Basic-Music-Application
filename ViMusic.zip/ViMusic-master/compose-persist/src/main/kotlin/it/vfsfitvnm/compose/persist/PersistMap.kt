package it.vfsfitvnm.compose.persist

typealias PersistMap = HashMap<String, Any?>
